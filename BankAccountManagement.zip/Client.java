import java.util.Iterator;
import java.util.HashSet;
import java.util.Set;
import java.util.Scanner;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.math.BigInteger;
import java.util.Random;
import java.util.Base64;
import java.security.SecureRandom;

class Client {
	static int numberOfClient = 0;
	protected String id;
	protected String password; // 로그인 시 pw
	protected String name; // 고객 이름
	protected String bankAccount; // 계좌번호 == 로그인 시 id
	protected int balance = 0; // 잔액

	// 예금, 출금, 잔액확인 등 통장 주요 메소드-----------------------------------------------------
	public void deposit(int depositAmount) { // 입금 메소드
		balance += depositAmount;
	}

	public boolean withdraw(int withdrawAmount) { // 출금메소드
		if (withdrawAmount > balance) // 출금금액이 잔액보다 클 경우 false반환
			return false;
		else {
			balance -= withdrawAmount;
			return true;
		}
	}

	public void checkBalance() { // 잔액확인메소드
		System.out.println("현재 잔액:" + balance + "원");
	}

	// 예금, 출금, 잔액확인 등 통장 주요 메소드-----------------------------------------------------
	// 계좌 신설 시 멤버 초기화에 관한
	// 메소드(Setter)-------------------------------------------------
	public Client() {
		// BLANK
	}

	public void setName(String name) { // 계좌 신설 후 고객의 이름 저장 메소드
		this.name = name;
	}

	public void setId(String id) { // 계좌 신설 후 고객의 계좌번호(ID) 저장 메소드
		this.id = id;
	}

	public void setPassword(String password) {
		try {
			MessageDigest md = MessageDigest.getInstance("SHA-512");
			md.update(password.getBytes());
			String hex = String.format("%128x", new BigInteger(1, md.digest()));
			this.password = hex;
		} catch (NoSuchAlgorithmException e) {
			System.out.println("Something is wrong");
		}
	}

	// 계좌 신설 시 멤버 초기화에 관한
	// 메소드(Setter)-------------------------------------------------
	// 계좌 이용 시 멤버 참조에 관한
	// 메소드(Getter)---------------------------------------------------
	public String getId() {
		return id;
	}

	protected String getPassword() {
		return password;
	}

	public String getName() {
		return name;
	}

	public String getBankAccount() {
		return bankAccount;
	}

	public int getBalance() {
		return balance;
	}

	static public String getPasswordHashing(String password) {
		try {
			MessageDigest md = MessageDigest.getInstance("SHA-512");
			md.update(password.getBytes());
			String hex = String.format("%128x", new BigInteger(1, md.digest()));
			return hex;
		} catch (NoSuchAlgorithmException e) {
			System.out.println("Something is wrong");
			return "Wrong";
		}
	}

	// 계좌 이용 시 멤버 참조에 관한
	// 메소드(Getter)---------------------------------------------------
	// 계좌 이용 시 사용자의 정보를 출력하는 메소드----------------------------------------------------
	public void showInfoOfClient() {
		System.out.println("성명: " + getName());
		System.out.println("계좌번호: " + getBankAccount());
		System.out.println("현재 잔액:" + getBalance() + "원");
		// System.out.println(getPassword());
	}
	// 계좌 이용 시 사용자의 정보를 출력하는 메소드----------------------------------------------------

	public void remittance(int money, String destPerson, Set<Client> clientDB){
		Client destClient = new Client();
		destClient = null;
		for (Client c : clientDB){
			if (c.getName().equals(destPerson)){
				destClient = c;
				break;
			}
		}
		if(destClient==null){
			System.out.println("그런사람 없음.");
			return;
		}
		this.withdraw(money);
		destClient.deposit(money);
	}
	@Override
	public boolean equals(Object obj) {
		if (id.equals(((Client) obj).id))
			return true;
		else
			return false;
	}

	@Override
	public int hashCode() {
		return ((id.hashCode()) + 100) % 17;
	}
}