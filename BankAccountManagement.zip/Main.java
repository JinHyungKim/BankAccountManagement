import java.util.Iterator;
import java.util.HashSet;
import java.util.Set;
import java.util.Scanner;

class Main {
	public static void main(String[] args) {
		String select;
		String trialId;
		String trialPw;
		int money;
		Set<Client> clientDatabase = new HashSet<>();
		Scanner sc = new Scanner(System.in);
		while (true) {
			PrintText.printSeparateLine();
			PrintText.firstMessage();
			PrintText.printSeparateLine();

			select = sc.nextLine();
			switch (select) {
			case "1":
				PrintText.toLogInId();
				trialId = sc.nextLine();
				PrintText.toLogInPw();
				trialPw = sc.nextLine();
				Client connectedClient = new Client();
				for (Client c : clientDatabase) {
					if (c.getId().equals(trialId) && c.getPassword().equals(Client.getPasswordHashing(trialPw))) {
						connectedClient = c;
						while (true) {
							PrintText.printSeparateLine();
							PrintText.logInSuccessAndWhatToDo();
							PrintText.printSeparateLine();
							select = sc.nextLine();
							switch (select) {
							case "1":
								PrintText.depositHowMuch();
								money = sc.nextInt();
								connectedClient.deposit(money);
								connectedClient.getBalance();
								break;
							case "2":
								PrintText.withdrawHowMuch();
								money = sc.nextInt();
								connectedClient.withdraw(money);
								connectedClient.getBalance();
								break;
							case "3":
								connectedClient.showInfoOfClient();
								break;
							case "4":
								System.out.print("송금액: ");
								
								money = sc.nextInt();
								sc.nextLine();
								System.out.print("받는 분: ");
								String dest = sc.nextLine();
								
								connectedClient.remittance(money, dest, clientDatabase);
							case "5":
								break;
							default:
							}
							if (select.equals("5"))
								break;
						}
					}
				}
				break;
			case "2": // 가입 메소드 호출
				PrintText.makeNewIdMessage();
				ShinhanBank newClient = new ShinhanBank();
				newClient.setId(sc.nextLine());
				if (clientDatabase.add(newClient)) {
					PrintText.makeNewPwMessage();
					newClient.setPassword(sc.nextLine());
					PrintText.makeNewNameMessage();
					newClient.setName(sc.nextLine());
					newClient.setAccount();
					Client.numberOfClient++;
				} else
					PrintText.chekingDuplicatedId();
				break;
			case "3":
				return;
			default:
				PrintText.wrongInputMessaage();
			}
		}
	}
}