class PrintText {
	public static void firstMessage() {
		System.out.println("1. SIGN IN\t\t\t2. SIGN UP\t\t\t3. END OF PROGRAM");
	}

	public static void toLogInId() {
		System.out.print("ID: ");
	}

	public static void toLogInPw() {
		System.out.print("PW: ");
	}

	public static void logInSuccessAndWhatToDo() {
		System.out.println("1. Deposit\t\t\t2. Withdraw\t\t\t3. Check Info\t\t\t4. Remittance\t\t\t5. Logout");
	}

	public static void depositHowMuch() {
		System.out.println("입금할 금액: ");
	}

	public static void withdrawHowMuch() {
		System.out.println("출금할 금액: ");
	}

	public static void makeNewIdMessage() {
		System.out.print("개설 할 ID를 입력하십시오: ");
	}

	public static void makeNewPwMessage() {
		System.out.print("개설 할 계좌의 비번을 입력하십시오: ");
	}

	public static void makeNewNameMessage() {
		System.out.print("성명을 입력하십시오: ");
	}

	public static void chekingDuplicatedId() {
		System.out.println("중복 된 ID입니다.");
	}

	public static void wrongInputMessaage() {
		System.out.println("잘못된 입력입니다.");
	}
	public static void printSeparateLine(){
		System.out.println("==========================================================");
	}
}
