import java.util.Random;
import java.util.Date;
import java.text.SimpleDateFormat;

interface MakingBankAccount {
	public void setAccount();
}

class ShinhanBank extends Client implements MakingBankAccount {
	private final int bankSerialNumber = 110;

	@Override
	public void setAccount() {
		Date date_now = new Date(System.currentTimeMillis());
		SimpleDateFormat fourteen_format = new SimpleDateFormat("ddHHmmss");
		Random rand = new Random();
		rand.setSeed(System.currentTimeMillis());
		bankAccount = (new StringBuilder(String.valueOf(bankSerialNumber)).append("-")
				.append(fourteen_format.format(date_now)).append(rand.nextInt(10))).toString();
	}
}